#!/bin/sh

APP_DIR="/data/venus-data/large-apps/nodalis"
mkdir -p "$APP_DIR"

cp /tmp/nodalis/index.html "$APP_DIR/index.html"
cp /tmp/nodalis/logo.png "$APP_DIR/logo.png"

touch "$APP_DIR/enabled"

echo "✅ App Nodalis installata correttamente in $APP_DIR"
