#!/bin/sh

# Crea la directory se non esiste
mkdir -p /data/www/nodalis

# Copia i file index.html e logo.png nella web root
cp index.html /data/www/nodalis/
cp logo.png /data/www/nodalis/

# Riavvia il server web (se necessario)
if command -v sv >/dev/null 2>&1; then
  sv restart lighttpd
elif command -v systemctl >/dev/null 2>&1; then
  systemctl restart lighttpd
fi

echo "✅ Webapp Nodalis installata"
